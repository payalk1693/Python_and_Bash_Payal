# Task 1: Grade Checker
# Takes a score as input and prints the grade using if / elif / else.

score = float(input("Enter the score: "))

if score >= 90:
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
elif score >= 60:
    print("Grade: D")
else:
    print("Grade: F")
