# Task 3: Write to a File
# Creates a text file and writes some content to it using open() and write().

file = open("sample.txt", "w")

file.write("Hello! This file was created using Python.\n")
file.write("Name: Payal\n")
file.write("Topic: Python and Bash DevOps Assignment\n")
file.write("File handling is easy with open() and write().\n")

file.close()

print("sample.txt has been created and written successfully.")
