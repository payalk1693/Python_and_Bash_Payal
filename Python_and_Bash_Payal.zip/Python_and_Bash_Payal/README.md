# Python & Bash – DevOps Assignment

Author: Payal

Core Python practice: conditionals, dictionaries and file handling.

## Files

| File | Task |
|------|------|
| `grade_checker.py` | Task 1 – Grade Checker (if / elif / else) |
| `student_grades.py` | Task 2 – Student Grades (dictionary, add / update / print) |
| `write_file.py` | Task 3 – Write to a File (`open()`, `write()`) |
| `read_file.py` | Task 4 – Read from a File (`open()`, `read()`) |
| `sample.txt` | File created by Task 3 and read by Task 4 |
| `Python_and_Bash_Payal_Documentation.docx` | Commands, screenshots and explanations |

## How to run

```bash
python3 grade_checker.py
python3 student_grades.py
python3 write_file.py     # creates sample.txt
python3 read_file.py      # run after write_file.py
```
