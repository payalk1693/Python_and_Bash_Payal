# Task 4: Read from a File
# Opens the file in read mode and displays its content using file.read().

file = open("sample.txt", "r")

content = file.read()
print("Content of sample.txt:\n")
print(content)

file.close()
